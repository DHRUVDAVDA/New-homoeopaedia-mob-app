import React from "react";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";
import {
  AntDesign,
  Ionicons,
  FontAwesome,
  MaterialIcons,
} from "@expo/vector-icons";

type MyProps = {
  navigation: any;
  page: string;
};

const Footer = ({ navigation, page }: MyProps) => {
  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={() => navigation.navigate("Home")}
        style={styles.single}
      >
        <Ionicons
          name="home"
          size={20}
          color={page === "Home" ? "#22bdc1" : "#000000"}
        />
        {page === "Home" && (
          <Text
            style={[
              styles.text,
              { color: page === "Home" ? "#22bdc1" : "#000000" },
            ]}
          >
            Home
          </Text>
        )}
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => navigation.navigate("QSubList")}
        style={styles.single}
      >
        <AntDesign
          name="questioncircle"
          size={20}
          color={page === "Question" ? "#22bdc1" : "#000000"}
        />
        {page === "Question" && (
          <Text
            style={[
              styles.text,
              {
                color: page === "Question" ? "#22bdc1" : "#000000",
              },
            ]}
          >
            Questions
          </Text>
        )}
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => navigation.navigate("MockScreen")}
        style={styles.single}
      >
        <FontAwesome
          name="file-text"
          size={20}
          color={page === "Mock" ? "#22bdc1" : "#000000"}
        />
        {page === "Mock" && (
          <Text
            style={[
              styles.text,
              { color: page === "Mock" ? "#22bdc1" : "#000000" },
            ]}
          >
            Tests
          </Text>
        )}
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => navigation.navigate("VideoList")}
        style={styles.single}
      >
        <MaterialIcons
          name="video-library"
          size={20}
          color={page === "Video" ? "#22bdc1" : "#000000"}
        />
        {page === "Video" && (
          <Text
            style={[
              styles.text,
              { color: page === "Video" ? "#22bdc1" : "#000000" },
            ]}
          >
            Videos
          </Text>
        )}
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#cccccc",
    paddingTop: 5,
    paddingBottom: 5,
    flexDirection: "row",
    alignItems: "center",
  },
  single: {
    flex: 1,
    alignItems: "center",
  },
  text: {
    // fontWeight: "bold",
    fontFamily:"Lato-Bold",
    fontSize: 12,
  },
});

export default Footer;
