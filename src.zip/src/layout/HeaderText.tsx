import React from "react";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";
import { FontAwesome, Feather, Ionicons } from "@expo/vector-icons";

type MyProps = {
	navigation: any;
	heading: string;
};

const HeaderText = ({ navigation, heading }: MyProps) => {
	return (
		<View style={styles.container}>
			<TouchableOpacity onPress={() => navigation.openDrawer()}>
				<FontAwesome name="navicon" size={30} color="#ffffff" />
			</TouchableOpacity>
			<Text style={styles.name}>{heading}</Text>
			<TouchableOpacity
				onPress={() => navigation.navigate("Notification")}
				style={styles.search}
			>
				<Ionicons name="notifications" size={28} color="#ffffff" />
			</TouchableOpacity>
			{/* <TouchableOpacity
				onPress={() => navigation.navigate("Search")}
				style={styles.search}
			>
				<Feather name="search" size={28} color="#ffffff" />
			</TouchableOpacity> */}
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		backgroundColor: "#22bdc1",
		paddingTop: 10,
		paddingBottom: 10,
		paddingLeft: 20,
		paddingRight: 20,
		flexDirection: "row",
		alignItems: "center",
	},
	name: {
		flex: 1,
		color: "#ffffff",
		// fontWeight: "bold",
		fontFamily:"Lato-Black",
		textTransform: "uppercase",
		fontSize: 20,
		justifyContent: "center",
		textAlign: "center",
	},
	search: {
		alignItems: "flex-end",
	},
});

export default HeaderText;
