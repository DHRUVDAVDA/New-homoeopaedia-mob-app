import React from 'react'
import { View } from 'react-native'
import Footer from '../layout/Footer'
import HeaderText from '../layout/HeaderText'
import styles from '../mock/ListStyles'
import { connect } from 'react-redux'
import { User } from '../_redux/reducers/types'
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs'
import Free from './Free'
import Paid from './PSubject'

type MyProps = {
  navigation: any
  user: User
  token: string
}

const Tab = createMaterialTopTabNavigator()

const List = ({ navigation }: MyProps) => {
  return (
    <View style={styles.container}>
      <HeaderText navigation={navigation} heading={`Rapid Revision`}/>
      <Tab.Navigator
        tabBarOptions={{
          labelStyle: { textTransform: 'none' },
        }}
        screenOptions={{
          tabBarLabelStyle: {
            textTransform: "none",
            fontFamily: "Lato-Black"
          },
        }}
      >
        <Tab.Screen
          name="Free"
          children={() => <Free navigation={navigation} />}
        />
        <Tab.Screen
          name="Paid"
          children={() => <Paid navigation={navigation} />}
        />
      </Tab.Navigator>
      <Footer navigation={navigation} page={`Video`} />
    </View>
  )
}

const mapStateToProps = (state: any) => ({
  isAuthenticated: state.authReducer.isAuthenticated,
  user: state.authReducer.user,
  token: state.authReducer.token,
})

export default connect(mapStateToProps)(List)
