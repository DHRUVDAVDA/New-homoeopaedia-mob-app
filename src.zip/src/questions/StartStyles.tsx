import { StyleSheet } from "react-native";

const StartStyles = StyleSheet.create({
	container: {
		flex: 1,
	},
	contentContainer: {
		flex: 1,
		margin: 20,
		marginTop: 10,
		marginBottom: 10,
	},
	header: {
		flexDirection: "row",
		alignItems: "center",
		marginBottom: 10,
	},
	logo: {
		flex: 1,
		textTransform: "uppercase",
		color: "#22bdc1",
		// fontWeight: "bold",
		fontFamily:"Lato-Black"
	},
	progressBar: {
		flexDirection: "row",
		height: 5,
		width: "100%",
	},
	scroller: {
		marginBottom: 10,
	},
	singleOption: {
		padding: 10,
		marginTop: 10,
		elevation: 1,
	},
	corw: {
		marginTop: 10,
		marginBottom: 10,
		flexDirection: "row",
		justifyContent: "space-between",
		alignItems: "center",
	},
	sameline: {
		flexDirection: "row",
		alignItems: "center",
		flex: 1,
	},
	remaining: {
		backgroundColor: "#22bdc1",
		color: "#ffffff",
		borderRadius: 50,
		paddingTop: 5,
		paddingBottom: 5,
		paddingLeft: 8,
		paddingRight: 8,
	},
	circle: {
		width: 10,
		height: 10,
		borderRadius: 20,
		marginRight: 5,
	},
	circleRed: {
		backgroundColor: "red",
	},
	circleGreen: {
		backgroundColor: "green",
	},
	circleGrey: {
		backgroundColor: "#cccccc",
	},
	singlOptExp: {
		marginTop: 5,
	},
	green: {
		color: "green",
		marginLeft: 5,
	},
	red: {
		color: "red",
		marginLeft: 5,
	},
	blackNew: {
		color: "#000000",
		marginLeft: 5,
	},
	whiteNew: {
		color: "#ffffff",
		marginLeft: 5,
	},
	black: {
		color: "#000000",
		marginLeft: 23,
	},
	white: {
		color: "#ffffff",
		marginLeft: 23,
	},
	iconOption: {
		flexDirection: "row",
		alignItems: "center",
	},
	icon: {
		marginTop: 5,
	},
	explain: {
		marginTop: 20,
	},
	nextBtn: {
		textTransform: "uppercase",
		backgroundColor: "#22bdc1",
		padding: 10,
		borderRadius: 20,
		textAlign: "center",
		color: "#ffffff",
		fontFamily:"Lato-Black"
	},
	centeredView: {
		flex: 1,
		justifyContent: "center",
		// alignItems: "center",
		backgroundColor: "rgba(0, 0, 0, 0.5)",
	},
	modalView: {
		margin: 20,
		backgroundColor: "white",
		borderRadius: 20,
		padding: 20,
		alignItems: "center",
		shadowColor: "#000",
		shadowOffset: {
			width: 0,
			height: 2,
		},
		shadowOpacity: 0.25,
		shadowRadius: 4,
		elevation: 5,
	},
	button: {
		borderRadius: 20,
		padding: 10,
		elevation: 2,
		marginTop: 20,
		flex: 1,
	},
	buttonOpen: {
		backgroundColor: "#F194FF",
	},
	buttonClose: {
		backgroundColor: "#2196F3",
	},
	textStyle: {
		color: "white",
		fontFamily:"Lato-Black",
		textAlign: "center",
	},
	modalText: {
		marginBottom: 15,
		textAlign: "center",
		fontSize: 16,
		// fontWeight: "bold",
		fontFamily:"Lato-Bold"
	},
	label: {
		textAlign: "left",
		alignSelf: "flex-start",
		fontFamily:"Lato-Regular"
	},
	modalButtons: {
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "space-between",
	},
	mr10: {
		marginRight: 10,
		backgroundColor: "green",
	},
	ml10: {
		marginLeft: 10,
	},
	report: {
		marginTop: 20,
		fontSize: 16,
		fontFamily:"Lato-Bold",
		color: "#F00",
	},
	issue: {
		borderColor: "#000000",
		borderWidth: 1,
		padding: 10,
		width: "100%",
		marginTop: 10,
	},
	txt:{
		fontFamily:"Lato-Bold"
	}
});

export default StartStyles;
