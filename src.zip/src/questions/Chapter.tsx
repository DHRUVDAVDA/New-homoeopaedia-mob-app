import React from "react";
import { View, Text } from "react-native";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import Footer from "../layout/Footer";
import HeaderBack from "../layout/HeaderBack";
import styles from "./SubjectStyles";
import All from "./All";
import Completed from "./Completed";
import Unattempted from "./Unattempted";
import Paused from "./Paused";

type MyProps = {
	route: any;
	navigation: any;
};

const Tab = createMaterialTopTabNavigator();

const Chapter = ({ route, navigation }: MyProps) => {
	const { heading, subId, subSlug } = route.params;

	return (
		<View style={styles.container}>
			<HeaderBack navigation={navigation} heading={heading} />
			<Tab.Navigator
				tabBarOptions={{
					labelStyle: { textTransform: "none" },
					tabStyle: {
						width: "auto",
					},
				}}
				screenOptions={{
					tabBarLabelStyle: {
						textTransform: "none",
						fontFamily: "Lato-Black"
					},
				}}
			>
				<Tab.Screen
					name="All"
					children={() => (
						<All
							navigation={navigation}
							subId={subId}
							subSlug={subSlug}
						/>
					)}
				/>
				<Tab.Screen
					name="Paused"
					children={() => (
						<Paused navigation={navigation} subId={subId} />
					)}
				/>
				<Tab.Screen
					name="Completed"
					children={() => (
						<Completed navigation={navigation} subId={subId} />
					)}
				/>
				<Tab.Screen
					name="Unattempted"
					children={() => (
						<Unattempted navigation={navigation} subId={subId} />
					)}
				/>
			</Tab.Navigator>
			<Footer navigation={navigation} page={`Question`} />
		</View>
	);
};

export default Chapter;
