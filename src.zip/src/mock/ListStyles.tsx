import { StyleSheet } from "react-native";

const ListStyles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#e9e9e9",
	},
	content: {
		flex: 1,
		paddingBottom: 5,
	},
	boxContainer: {
		backgroundColor: "#ffffff",
		borderRadius: 5,
		padding: 10,
		marginLeft: 20,
		marginRight: 20,
		marginTop: 10,
		marginBottom: 5,
		elevation: 1,
	},
	heading: {
		fontWeight: "bold",
	},
	subheading: {
		color: "#22bdc1",
	},
	mockSingle: {
		backgroundColor: "#ffffff",
		borderRadius: 5,
		marginBottom: 10,
	},
	enrollNow: {
		backgroundColor: "#F67602",
		color: "#ffffff",
		textAlign: "center",
		paddingTop: 10,
		paddingBottom: 10,
		borderBottomLeftRadius: 5,
		borderBottomRightRadius: 5,
		fontWeight: "bold",
	},
	mockContents: {
		padding: 20,
		paddingTop: 10,
		paddingBottom: 10,
	},
	mockHeading: {
		fontWeight: "bold",
		fontSize: 16,
		marginBottom: 10,
	},
	padding: {
		padding: 20,
		paddingBottom: 10,
		// flex: 1,
	},
});

export default ListStyles;
