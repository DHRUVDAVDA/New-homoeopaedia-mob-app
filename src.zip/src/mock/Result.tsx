import React, { useEffect, useState } from "react";
import { BackHandler, ScrollView, Text, View } from "react-native";
import styles from "./ResultStyle";
import { connect } from "react-redux";
import { User } from "../_redux/reducers/types";
import Back from "../layout/Back";
import axios from "axios";
import { BASE_URL } from "../consts";
import Loading from "../layout/Loading";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import ResultOverview from "./ResultOverview";
import Solution from "./Solution";
import Toast from "react-native-simple-toast";
import ShowRankModal from "./ShowRankModal";

type MyProps = {
	navigation: any;
	user: User;
	token: string;
	route: any;
};

const Tab = createMaterialTopTabNavigator();

const Result = ({ navigation, route, user, token }: MyProps) => {
	const { titleId } = route.params;
	const [chartData, setChartData] = useState([]);
	const [totalMarks, setTotalMarks] = useState({});
	const [loading, setLoading] = useState(true);
	const [showRank, setShowRank] = useState(false);

	useEffect(() => {
		const backHandler = BackHandler.addEventListener(
			"hardwareBackPress",
			() => {
				// setShowRank(true);
				navigation.navigate("MockScreen");

				return true; // Prevent default behavior (exit app)
			},
		);

		return () => backHandler.remove();
	}, []);

	useEffect(() => {
		saveStatus();
		getMarks();
	}, []);

	const saveStatus = async () => {
		await axios
			.post(
				`${BASE_URL}/savemockstatus/${user.user_id}/${titleId}?api_token=${token}`,
				{ status: "Completed" },
			)
			.then(
				(res) => { },
				(error) => { },
			);
	};

	// const getMarks = async () => {
	// 	try {
	// 		const response = await axios.get(
	// 			`${BASE_URL}/mmarks/${user.user_id}/${titleId}?api_token=${token}`,
	// 		);
	// 		const { data } = response;
	// 		console.log("mmarks api response", data)
	// 		if (data.success) {
	// 			console.log("mmarks", data.result)
	// 			let pos_marks = 0;
	// 			let neg_marks = 0;

	// 			const correct = data.result.filter(
	// 				(result: any) => result.options_id === result.correct_ans,
	// 			);
	// 			const wrong = data.result.filter(
	// 				(result: any) => result.options_id !== result.correct_ans,
	// 			);
	// 			const review = data.result.filter(
	// 				(result: any) => result.review === "mark_review_next",
	// 			);
	// 			const guess = data.result.filter(
	// 				(result: any) => parseInt(result.guess) === 1,
	// 			);

	// 			correct.forEach((result: any) => {
	// 				switch (parseInt(result.calculation_id)) {
	// 					case 1:
	// 						pos_marks += 1;
	// 						break;
	// 					case 2:
	// 						pos_marks += 4;
	// 						break;
	// 					case 3:
	// 						pos_marks += 2;
	// 						break;
	// 					default:
	// 						break;
	// 				}
	// 			});

	// 			wrong.forEach((result: any) => {
	// 				switch (parseInt(result.calculation_id)) {
	// 					case 1:
	// 						break; // no negative marks
	// 					case 2:
	// 						neg_marks -= 1;
	// 						break;
	// 					case 3:
	// 						neg_marks -= 0.66;
	// 						break;
	// 					default:
	// 						break;
	// 				}
	// 			});

	// 			setChartData([
	// 				{
	// 					name: "Correct Answers",
	// 					population: correct.length,
	// 					color: "green",
	// 					legendFontColor: "#7F7F7F",
	// 					legendFontSize: 15,
	// 				},
	// 				{
	// 					name: "Wrong Answers",
	// 					population: wrong.length,
	// 					color: "#F00",
	// 					legendFontColor: "#7F7F7F",
	// 					legendFontSize: 15,
	// 				},
	// 			]);


	// 			console.log("review only", review)

	// 			setTotalMarks({
	// 				marks: pos_marks - Math.abs(neg_marks),
	// 				correct: correct.length,
	// 				wrong: wrong.length,
	// 				attempted: data.result.length,
	// 				review: review.length,
	// 				guess: guess.length,
	// 				date: data.result[0].updated_at,
	// 			});
	// 			setShowRank(true);
	// 		}

	// 		setLoading(false);
	// 	} catch (error) {
	// 		setLoading(false);
	// 		Toast.show("Network error. Try again.", Toast.LONG);
	// 	}
	// };

	const getMarks = async () => {
		try {
			const response = await axios.get(
				`${BASE_URL}/mmarks/${user.user_id}/${titleId}?api_token=${token}`
			);
			const { data } = response;

			if (data.success) {


				setChartData([
					{
						name: "Correct Answers",
						population: data.result.correct_answers_count,
						color: "#12b57e",
						legendFontColor: "#7F7F7F",
						legendFontSize: 15,
					},
					{
						name: "Wrong Answers",
						population: data.result.wrong_answer_count,
						color: "#DC143C",
						legendFontColor: "#7F7F7F",
						legendFontSize: 15,
					},
					{
						name: "Unattempted",
						population: data.result.unattempted_qus_count,
						color: "#bdc3fc",
						legendFontColor: "#7F7F7F",
						legendFontSize: 15,
					},
				]);

				setTotalMarks({
					marks: data.result.obtained_marks,
					correct: data.result.correct_answers_count,
					wrong: data.result.wrong_answer_count,
					attempted: data.result.attempted_qus_count, // Only count answered questions
					unattempted: data.result.unattempted_qus_count, // Count skipped questions
					review: data.result.review_qus_count,
					guess: data.result.guess_qus_count,
					date: data.result.exam_date,
					total_marks: data.result.total_marks
				});

				setShowRank(true);
			}

			setLoading(false);
		} catch (error) {
			setLoading(false);
			Toast.show("Network error. Try again.", Toast.LONG);
		}
	};


	const closeModal = async () => {
		setShowRank(false);
		// navigation.navigate("MockScreen");
	}

	return (
		<View style={styles.container}>
			<Loading loading={loading} text="Loading results. Please wait." />
			<Back navigation={navigation} type="MockScreen" />
			<View style={styles.innerContainer}>
				<Text style={[styles.heading, styles.mb20]}>
					Performance card
				</Text>
				<Tab.Navigator
					lazy={true}
					tabBarOptions={{
						labelStyle: { textTransform: "none" },
					}}
					screenOptions={{
						tabBarLabelStyle: {
							textTransform: "none",
							fontFamily: "Lato-Black"
						},
					}}
				>
					<Tab.Screen
						name="Analysis"
						children={() => (
							<ResultOverview
								navigation={navigation}
								route={route}
								totalMarks={totalMarks}
								chartData={chartData}
							/>
						)}
					/>
					<Tab.Screen
						name="Solution"
						children={() => (
							<Solution
								navigation={navigation}
								route={route}
								totalMarks={totalMarks}
								chartData={chartData}
							/>
						)}
					/>
				</Tab.Navigator>
			</View>

			<ShowRankModal
				modalVisible={showRank}
				setModalVisible={setShowRank}
				closeModal={closeModal}
				titleId={titleId}
				userId={user.user_id}
			/>
		</View>
	);
};

const mapStateToProps = (state: any) => ({
	isAuthenticated: state.authReducer.isAuthenticated,
	user: state.authReducer.user,
	token: state.authReducer.token,
});

export default connect(mapStateToProps)(Result);
