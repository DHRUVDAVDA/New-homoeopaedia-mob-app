import React from "react";
import { Image, Text, TouchableOpacity, View, Dimensions } from "react-native";
import styles from "./ResultStyle";
import HTML from "react-native-render-html";
import { WEB_URL } from "../consts";

const { width } = Dimensions.get('window');

interface SolutionItemProps {
	item: any;
	index: number;
	active: any;
	navigation: any;
	totalQues: number;
	titleId: number;
}

const SolutionItem: React.FC<SolutionItemProps> = ({
	item,
	index,
	active,
	navigation,
	totalQues,
	titleId,
}) => {
	const checkAnswerText = (
		correct_ans: number,
		options_id: any,
		type: string,
	) => {
		if (correct_ans === options_id) {
			return "Correct";
		} else if (type === "answered" && correct_ans !== options_id) {
			return "Wrong";
		} else if (type === "visited") {
			if (options_id === null || options_id === 0) return "Visited";
			else return "Wrong";
		} else if (type === null) {
			return "Unattempted";
		} else {
			return "Wrong";
		}
	};

	const answerText = checkAnswerText(
		parseInt(item.correct_ans),
		item.manswers.length > 0 ? parseInt(item.manswers[0].options_id) : null,
		item.manswers.length > 0 ? item.manswers[0].type : null,
	);

	const numberingStyle =
		answerText === "Correct"
			? styles.numberingActive
			: answerText === "Wrong"
				? styles.numberingWrong
				: styles.numbering;

	const colorStyle =
		answerText === "Correct"
			? styles.colorGreen
			: answerText === "Wrong"
				? styles.colorRed
				: styles.colorGrey;

	const isValidExplanation = (expl) => {
		if (!expl) return false;

		// Remove all HTML tags and trim whitespace & newlines
		const stripped = expl.replace(/<[^>]*>/g, "").replace(/\n/g, "").trim();

		// Return true only if meaningful content exists
		return stripped.length > 0;
	};


	return (
		<TouchableOpacity
			onPress={() =>
				navigation.navigate("MockResultQues", {
					titleId: titleId,
					totalQues: totalQues,
					title: "",
				})
			}
			style={styles.answer}
			key={item.id}
		>
			<Text style={[numberingStyle, styles.qtxt]}>
				{parseInt(active.split("-")[0]) + index}
			</Text>
			<View style={styles.flex}>
				<View>
					{/* <HTML
						source={{
							html: item.ques,
						}}
						contentWidth={width}
						baseStyle={{ marginTop: -15 }}
					/> */}
					<HTML
						contentWidth={width}
						source={{
							html: item.ques,
						}}
						tagsStyles={{
							body: { fontFamily: "Lato-Black", fontSize: 16 },
							p: { fontFamily: "Lato-Black", fontSize: 16 },
							span: { fontFamily: "Lato-Black", fontSize: 16 },
						}}
						defaultTextProps={{
							style: { fontFamily: "Lato-Black", fontSize: 16 },
						}}
						baseStyle={{ marginTop: -15 }}
					/>
					{item?.image && (
						<Image
							source={{
								uri: `${WEB_URL}${item?.image}`,
							}}
							style={styles.quesImage}
						/>
					)}
				</View>
				<View
					style={
						item.expl ? styles.answer : [styles.answer, styles.mb10]
					}
				>
					<Text style={[colorStyle, styles.qtxt]}>{answerText}</Text>
					<Text style={styles.dot}>.</Text>
					<Text style={[styles.colorGrey, styles.flex, styles.qtxt]}>
						{item.options_solutions.name}
					</Text>
				</View>
				{item.expl && isValidExplanation(item.expl) && (
					<View>
						<Text style={styles.thin}>Explanation</Text>
						<View>
							<HTML source={{ html: item.expl }}
								contentWidth={width}
								tagsStyles={{
									body: { fontFamily: "Lato-Regular", fontSize: 14 },
									p: { fontFamily: "Lato-Regular", fontSize: 14 },
									span: { fontFamily: "Lato-Regular", fontSize: 14 },
								}}
								defaultTextProps={{
									style: { fontFamily: "Lato-Regular", fontSize: 14 },
								}}
							/>
						</View>
					</View>
				)}

			</View>
		</TouchableOpacity>
	);
};

export default SolutionItem;
