import React, { useState } from "react";
import All from "../mocklist/all";
import Completed from "../mocklist/completed";
import Notstarted from "../mocklist/notstarted";
import Paused from "../mocklist/paused";
import { StyleSheet, Text, TouchableOpacity, View, Dimensions } from "react-native";
import { connect } from "react-redux";

const width = Dimensions.get('window').width;

type MyProps = {
  navigation: any;
  user: User;
  tab: string;
  token: string;
};

const Mock = React.memo(({ navigation, user, token}: MyProps) => {
    const [menuItems, setMenuItems] = useState([
        { id: '1', name: 'All' },
        { id: '2', name: 'Completed' },
        { id: '3', name: 'Notstarted' },
        { id: '4', name: 'Paused' },
    ]);
    const [selMenu, setSelMenu] = useState('1');

    const setMenu = (id) => {
        setSelMenu(id);
    };
    return (
        <View style={styles.content}>
            <View style={styles.menu}>
                {menuItems.map((item, index) => (
                    <TouchableOpacity key={index} onPress={() => setMenu(item.id)} style={styles.menuItemContainer}>
                        <Text style={[styles.menuItem, item.id == selMenu ? styles.selMenuItem : null]}>{item.name}</Text>
                        {item.id == selMenu && <View style={styles.menuIndicator} />}
                    </TouchableOpacity>
                ))}
            </View>

            <View style={{ flex: 1, marginTop: '4%' }}>
                {selMenu === '1' && (
                    <All />
                )}
                {selMenu === '2' && (
                    <Completed />
                )}
                {selMenu === '3' && (
                    <Notstarted />
                )}
                {selMenu === '4' && (
                    <Paused />
                )}
            </View>
        </View>
    );
});

const mapStateToProps = (state: any) => ({
    isAuthenticated: state.authReducer.isAuthenticated,
    user: state.authReducer.user,
    token: state.authReducer.token,
  });

export default connect(mapStateToProps)(Mock);

const styles = StyleSheet.create({
    menu: {
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    menuItemContainer: {
        marginRight: '1.5%',
        alignItems: 'center',
    },
    menuItem: {
        fontSize: 14,
        color: '#000000',
        marginRight: '3%',
    },
    selMenuItem: {
        color: 'blue',
    },
    menuIndicator: {
        width: 30,
        height: 5,
        borderRadius: 3,
        backgroundColor: 'blue',
        alignSelf: 'center',
        marginTop: '2%',
    },
    content: {
        flex: 1,
        marginTop: '4%',
        width: width - 10,
        alignSelf: 'center',
    },
})
