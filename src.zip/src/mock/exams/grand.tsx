import React from "react";
import { Text } from "react-native";

const Grand = () => {
  return (
    <Text>Grand list</Text>
  );
};

export default Grand;
