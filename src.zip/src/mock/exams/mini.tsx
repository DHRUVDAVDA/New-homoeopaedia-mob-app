import React from "react";
import { Text } from "react-native";

const Mini = () => {
  return (
    <Text>Mini list</Text>
  );
};

export default Mini;