import React, { useEffect, useState } from "react";
import {
	Image, ScrollView, Dimensions, Text, View, TouchableOpacity, Modal, Pressable,
	TextInput
} from "react-native";
import styles from "./ResultStyle";
import { connect } from "react-redux";
import { User } from "../_redux/reducers/types";
// import { TouchableOpacity } from "react-native-gesture-handler";
import Back from "../layout/Back";
import axios from "axios";
import { BASE_URL, WEB_URL } from "../consts";
import Toast from "react-native-simple-toast";
import HTML from "react-native-render-html";
import Loading from "../layout/Loading";
import { Picker } from "@react-native-picker/picker";

type MyProps = {
	navigation: any;
	user: User;
	token: string;
	route: any;
};

const SolutionQues = ({ navigation, route, user, token }: MyProps) => {
	const { titleId, totalQues, title } = route.params;
	const [quesNo, setQuesNo] = useState(0);
	const [loading, setLoading] = useState(false);
	const [questions, setQuestions] = useState([]);
	const [option, setOption] = useState(0);
	const [response, setResponse] = useState({});
	const [modalVisible, setModalVisible] = useState(false);
	const [type, setType] = useState("");
	const [issue, setIssue] = useState("");
	const [index, setIndex] = useState(0);
	useEffect(() => {
		loadQuestions();
	}, []);

	const loadQuestions = async () => {
		setLoading(true);

		await axios
			.get(`${BASE_URL}/mquestions/${titleId}?api_token=${token}`)
			.then(
				(res) => {
					setQuestions(res.data.result);
				},
				(error) => {
					Toast.show("Network error. Try again.", Toast.LONG);
				},
			);

		setLoading(false);
	};

	const checkOptions = async (quesId: number, optionId: number) => {
		setOption(optionId);
		setLoading(true);

		const correct = questions[quesNo].correct_ans;
		const wrong =
			questions[quesNo].correct_ans !== optionId
				? optionId
				: questions[quesNo].correct_ans;

		await axios
			.get(
				`${BASE_URL}/checkanscount/${quesId}/${correct}/${wrong}?api_token=${token}`,
			)
			.then(
				(res) => {
					setResponse(res.data);
				},
				(error) => {
					Toast.show("Network error. Try again.", Toast.LONG);
				},
			);

		setLoading(false);
	};

	const saveReport = (quesID: number) => {
		if (!type) Toast.show("Report type required.", Toast.LONG);
		else if (!issue) Toast.show("Elaborate issue required.", Toast.LONG);
		else {
			setLoading(true);

			axios
				.post(`${BASE_URL}/report?api_token=${token}`, {
					user_id: user.user_id,
					quesID: quesID,
					type: type,
					issue: issue,
				})
				.then((response) => {
					setModalVisible(false);
					setLoading(false);

					Toast.show("Question successfully reported.", Toast.LONG);
				})
				.catch((error) => {
					setLoading(false);
					Toast.show("Network error. Tryagain.", Toast.LONG);
				});
		}
	};

	return (
		<View style={styles.containerNew}>
			<Loading loading={loading} text="Loading questions. Please wait." />
			<Back navigation={navigation} />
			<View style={styles.innerContainer}>
				<Text style={[styles.heading, styles.mb10]}>
					Questions 1 of {totalQues}
				</Text>
				<View style={styles.flex}>
					<View>
						<ScrollView
							horizontal
							showsHorizontalScrollIndicator={false}
							contentContainerStyle={styles.horizontal}
						>
							<View style={styles.pagination}>
								{Array.from({ length: totalQues }).map(
									(item, index) => (
										<TouchableOpacity
											onPress={() => {
												setQuesNo(index);
												setOption(0);
												setResponse({});
											}}
											key={index}
										>
											<Text
												style={
													index === quesNo
														? styles.paginationSingleActive
														: styles.paginationSingle
												}
											>
												{index + 1}
											</Text>
										</TouchableOpacity>
									),
								)}
							</View>
						</ScrollView>
					</View>
					<View>
						{questions.length > 0 && (
							<View>
								<HTML
									source={{
										html: questions[quesNo].ques,
									}}
								/>
								{questions[quesNo]?.image && (
									<Image
										source={{
											uri: `${WEB_URL}${questions[quesNo]?.image}`,
										}}
										style={styles.quesImage}
									/>
								)}
							</View>
						)}

						<TouchableOpacity style={styles.mt20}
							onPress={() =>
								setModalVisible(!modalVisible)
							}
						>
							<Text style={styles.fntStyle}>
								Report this Question
							</Text>
						</TouchableOpacity>

					</View>
				</View>
				{questions.length > 0 && (
					<View>
						{questions[quesNo].options.map((item: any) => (
							<TouchableOpacity
								onPress={() =>
									checkOptions(questions[quesNo].id, item.id)
								}
								key={item.id}
							>
								<Text
									style={
										option &&
											questions[quesNo].correct_ans ===
											item.id
											? [styles.options, styles.active]
											: option &&
												option !==
												questions[quesNo]
													.correct_ans &&
												option === item.id
												? [styles.options, styles.wrong]
												: styles.options
									}
								>
									{item.name}
								</Text>
								{response?.correct &&
									option &&
									questions[quesNo].correct_ans === item.id ? (
									<Text style={styles.correctText}>
										{Math.min(
											(response?.correct / totalQues) *
											100,
											100,
										)}
										% got this correct
									</Text>
								) : response?.wrong &&
									option &&
									option !== questions[quesNo].correct_ans &&
									option === item.id ? (
									<Text style={styles.wrongText}>
										{Math.min(
											(response?.wrong / totalQues) * 100,
											100,
										)}
										% marked this
									</Text>
								) : (
									<></>
								)}
							</TouchableOpacity>
						))}
					</View>
				)}
			</View>

			<Modal
				animationType="slide"
				transparent={true}
				visible={modalVisible}
				onRequestClose={() => {
					setModalVisible(!modalVisible);
				}}
			>
				<View style={styles.centeredView}>
					<View style={styles.modalView}>
						<Text style={styles.modalText}>
							Feedback/Report Error
						</Text>
						<Text style={styles.label}>
							What are you reporting?
						</Text>
						<View
							style={{
								alignSelf: "flex-start",
								borderWidth: 1,
								borderColor: "#000000",
								marginTop: 10,
								marginBottom: 10,
							}}
						>
							<Picker
								selectedValue={type}
								onValueChange={(item) =>
									setType(item)
								}
								style={{
									width:
										Dimensions.get(
											"window",
										).width - 80,
								}}
								mode="dropdown"
							>
								<Picker.Item
									label="---- Select Type ----"
									value=""
								/>
								<Picker.Item
									label="Factual error"
									value="Factual error"
								/>
								<Picker.Item
									label="Confusing question"
									value="Confusing question"
								/>
								<Picker.Item
									label="Inadequate explanation"
									value="Inadequate explanation"
								/>
							</Picker>
						</View>
						<Text style={styles.label}>
							Elaborate issue
						</Text>
						<TextInput
							multiline={true}
							value={issue}
							onChangeText={(e) =>
								setIssue(e)
							}
							style={styles.issue}
						/>
						<View style={styles.modalButtons}>
							<Pressable
								onPress={() =>
									saveReport(
										questions?.[
											quesNo
										]?.["id"],
									)
								}
								style={[
									styles.button,
									styles.buttonClose,
									styles.mr10,
								]}
							>
								<Text
									style={styles.textStyle}
								>
									Send
								</Text>
							</Pressable>
							<Pressable
								style={[
									styles.button,
									styles.buttonClose,
									styles.ml10,
								]}
								onPress={() =>
									setModalVisible(
										!modalVisible,
									)
								}
							>
								<Text
									style={styles.textStyle}
								>
									Close
								</Text>
							</Pressable>
						</View>
					</View>
				</View>
			</Modal>
		</View>
	);
};

const mapStateToProps = (state: any) => ({
	isAuthenticated: state.authReducer.isAuthenticated,
	user: state.authReducer.user,
	token: state.authReducer.token,
});


export default connect(mapStateToProps)(SolutionQues);
