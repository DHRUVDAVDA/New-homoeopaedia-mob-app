import { StyleSheet } from "react-native";

const InstructionStyles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#ffffff",
	},
	innerContainer: {
		marginHorizontal: 20,
		marginVertical: 10,
		flexGrow: 1,
	},
	displayFlex: {
		flexDirection: "row",
		alignItems: "center",
	},
	bold: {
		fontFamily: 'Lato-Bold',
		fontSize: 16,
	},
	subheading: {
		color: "#888888",
		fontFamily: 'Lato-Bold',
	},
	ms10: {
		marginStart: 10,
	},
	mt20: {
		marginTop: 20,
	},
	mt10: {
		marginTop: 10,
	},
	section: {
		marginTop: 20,
	},
	heading: {
		fontSize: 18,
		fontFamily: 'Lato-Bold',
	},
	footer: {
		borderTopColor: "#e9e9e9",
		borderTopWidth: 1,
		paddingVertical: 10,
		paddingHorizontal: 20,
		backgroundColor: "#ffffff",
	},
	btnStart: {
		backgroundColor: "#22bdc1",
		padding: 10,
		borderRadius: 5,
		marginTop: 10,
	},
	btnDisabled: {
		backgroundColor: "#888888",
		padding: 10,
		borderRadius: 5,
		marginTop: 10,
	},
	btnText: {
		textAlign: "center",
		color: "#ffffff",
		fontFamily: 'Lato-Black',
	},
	txt:{
		fontFamily: 'Lato-Regular',
	}
});

export default InstructionStyles;
