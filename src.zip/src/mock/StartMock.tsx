import React, { useState, useEffect } from "react";
import {
  Alert,
  BackHandler,
  Image,
  ScrollView,
  Text,
  TouchableOpacity,
  View,Dimensions
} from "react-native";
import styles from "./MockStyle";
import { connect } from "react-redux";
import { User } from "../_redux/reducers/types";
import { Ionicons } from "@expo/vector-icons";
import QuestionsModal from "./QuestionsModal";
import axios from "axios";
import { BASE_URL, WEB_URL } from "../consts";
import Toast from "react-native-simple-toast";
import Loading from "../layout/Loading";
import HTML from "react-native-render-html";
import { filter } from "lodash";
import EndModal from "./EndModal";
import PauseModal from "./PauseModal";
import moment from "moment";
import CheckBox from "react-native-checkbox";
import AllQuestionsModal from "./AllQuestionsModal";
import { setStatusBarBackgroundColor } from "expo-status-bar";

const contentWidth = Dimensions.get("window").width;

type MyProps = {
  navigation: any;
  user: User;
  token: string;
  route: any;
};

const StartMock = ({ navigation, route, user, token }: MyProps) => {
  const { titleId, totalQues, title, status, duration, start, end } =
    route.params;
  const [time, setTime] = useState(duration * 60);
  const [modal, setModal] = useState(false);
  const [isVerify, setVerifyQusModal] = useState(false);
  const [endModal, setEndModal] = useState(false);
  const [pauseModal, setPauseModal] = useState(false);
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [quesIndex, setQuesIndex] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [markReview, setMarkReview] = useState([]);
  const [guess, setGuess] = useState([]);
  const [skippedQues, setSkippedQues] = useState([]);
  const [isRunning, setIsRunning] = useState(true);
  const [isNextLoading, setIsNextLoading] = useState(false);
  const [isReviewing, setIsReviewing] = useState(false);
  const [testEndedManually, setTestEndedManually] = useState(false);

  /** Handle Restoring Time After Pausing */
  // useEffect(() => {
  //   if (status === "Paused") {
  //     const startDatetime = moment(start);
  //     console.log(startDatetime);
  //     const endDatetime = moment(end);
  //     const elapsedMinutes = endDatetime.diff(startDatetime, "minutes");
  //     const remainingSeconds = (duration - elapsedMinutes) * 60;
  //     console.log("remainingSeconds",remainingSeconds);
  //     setTime(remainingSeconds > 0 ? remainingSeconds : 0);
  //     setIsRunning(false); // Ensure the timer does not run until resumed
  //     loadPausedQuestions();
  //   } 
  // }, [status]);

  // useEffect(() => {
  //   if (status === "Paused") {
  //     const startDatetime = moment(start);
  //     console.log("startDatetime--", startDatetime)
  //     const endDatetime = moment(end);
  //     console.log("endDatetime--", endDatetime)
  //     const durations = endDatetime.diff(startDatetime, "minutes");
  //     const remainingMinutes = duration - durations;
  //     console.log("remainingMinutes--", remainingMinutes)
  //     setTime(remainingMinutes * 60);

  //     loadPausedQuestions();
  //   }
  // }, [status]);

  // useEffect(() => {
  //   if (status === "Paused") {
  //     const currentTime = moment(); // Current time when resuming
  //     const startTime = moment(start); // Exam start time
  //     const endTime = moment(end); // Exam scheduled end time

  //     // Calculate how much time passed
  //     const totalElapsedTime = currentTime.diff(startTime, "seconds");

  //     console.log("Current Time:", currentTime.format("YYYY-MM-DD HH:mm:ss"));
  //     console.log("Start Time:", startTime.format("YYYY-MM-DD HH:mm:ss"));
  //     console.log("End Time:", endTime.format("YYYY-MM-DD HH:mm:ss"));
  //     console.log("Total Elapsed Seconds:", totalElapsedTime);

  //     // If elapsed time exceeds the scheduled end time, end the exam
  //     if (currentTime.add(totalElapsedTime, "seconds").isAfter(endTime)) {
  //       console.log("Exam time exceeded. Ending exam...");
  //       confirmEnd();
  //     } else {
  //       // Calculate remaining time
  //       const remainingTime = endTime.diff(currentTime, "seconds");
  //       setTime(remainingTime > 0 ? remainingTime : 0);
  //       setIsRunning(false); // Ensure the timer is not running until resumed
  //     }

  //     loadPausedQuestions();
  //   }
  // }, [status]);

  // useEffect(() => {
  //   if (status === "Paused") {
  //     const currentTime = moment();
  //     const startTime = moment(start);
  //     const endTime = moment(end);
  //     const totalElapsedTime = currentTime.diff(startTime, "seconds");

  //     console.log("Total Elapsed Seconds:", totalElapsedTime);

  //     if (currentTime.isAfter(endTime)) { // Only check end time
  //       console.log("Exam time exceeded. Ending exam...");
  //       confirmEnd();
  //     } else {
  //       const remainingTime = endTime.diff(currentTime, "seconds");
  //       if (remainingTime > 0) {
  //         setTime(remainingTime); // Only update if time remains
  //         setIsRunning(false);
  //       }
  //     }

  //     loadPausedQuestions();
  //   }
  // }, [status]);

  useEffect(() => {
    let isMounted = true; // Flag to track if component is mounted

    if (status === "Paused" && isMounted) {
      const currentTime = moment();
      const startTime = moment(start);
      const endTime = moment(end);
      const totalElapsedTime = currentTime.diff(startTime, "seconds");

      console.log("Total Elapsed Seconds:", totalElapsedTime);

      if (currentTime.isAfter(endTime)) {
        console.log("Exam time exceeded. Ending exam...");
        if (isMounted) confirmEnd(); // Prevent calling after unmount
      } else {
        const remainingTime = endTime.diff(currentTime, "seconds");
        if (remainingTime > 0 && isMounted) {
          setTime(remainingTime);
          setIsRunning(false);
        }
      }

      loadPausedQuestions();
    }

    return () => {
      isMounted = false; // Prevent state updates after unmount
    };
  }, [status]);




  useEffect(() => {
    if (time === 0 && !testEndedManually) {
      console.log("### ys time up####")
      confirmEnd();
    }
  }, [time]);

  /** Handle Timer Countdown */
  // useEffect(() => {
  //   let interval;
  //   if (isRunning && time > 0) {
  //     interval = setInterval(() => {
  //       setTime((prevTime) => {
  //         if (prevTime <= 1) {
  //           clearInterval(interval);
  //           confirmEnd();
  //           return 0;
  //         }
  //         return prevTime - 1;
  //       });
  //     }, 1000);
  //   }
  //   return () => clearInterval(interval);
  // }, [isRunning, time]);

  useEffect(() => {
    let interval;
    if (isRunning && time > 0) {
      interval = setInterval(() => {
        setTime((prevTime) => {
          if (prevTime <= 1) {
            clearInterval(interval);
            confirmEnd();
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);
    }
    return () => {
      clearInterval(interval); // Clears interval when component unmounts
    };
  }, [isRunning, time]);



  /** Load Initial Questions */
  useEffect(() => {
    // Capture the start time when the exam begins
    const startTime = moment().format("YYYY-MM-DD HH:mm:ss");
    const endTime = moment().add(duration, "minutes").format("YYYY-MM-DD HH:mm:ss");

    console.log("Exam Start Time:", startTime);
    console.log("Exam End Time:", endTime);

    saveStatus("Started", startTime, endTime);
    loadQuestions();
  }, []);

  /** Handle Android Back Button */
  useEffect(() => {
    const backHandler = BackHandler.addEventListener("hardwareBackPress", () => {
      setEndModal(true);
      return true;
    });
    return () => backHandler.remove();
  }, []);

  // const loadPausedQuestions = async () => {
  //   setLoading(true);
  //   await axios
  //     .get(`${BASE_URL}/loadsavedmock/${user.user_id}/${titleId}?api_token=${token}`)
  //     .then((res) => {
  //       const answered = res.data.result
  //         .filter((item: any) => item.type === "answered")
  //         .map((item: any) => ({
  //           question_id: parseInt(item.questions_id),
  //           option_id: parseInt(item.options_id),
  //           type: "save-next",
  //         }));

  //       setSelectedOptions(answered);

  //       const visited = res.data.result
  //         .filter((item: any) => item.type === "visited")
  //         .map((item: any) => item.questions_id);
  //       setSkippedQues(visited);

  //       setLoading(false);
  //     })
  //     .catch(() => setLoading(false));
  // };

  const loadPausedQuestions = async () => {
    setLoading(true);
    await axios
      .get(`${BASE_URL}/loadsavedmock/${user.user_id}/${titleId}?api_token=${token}`)
      .then((res) => {
        const answered = res.data.result
          .filter((item: any) => item.type === "answered")
          .map((item: any) => ({
            question_id: parseInt(item.questions_id),
            option_id: parseInt(item.options_id),
            type: "save-next",
          }));

        setSelectedOptions(answered);

        const visited = res.data.result
          .filter((item: any) => item.type === "visited")
          .map((item: any) => item.questions_id);
        setSkippedQues(visited);

        // 🔹 Find the last attended question
        let lastAttendedQuestionId = answered.length > 0
          ? answered[answered.length - 1].question_id
          : visited.length > 0
            ? visited[visited.length - 1]
            : null;

        // 🔹 Get the index of the last attended question
        if (lastAttendedQuestionId) {
          const lastIndex = questions.findIndex(q => q.id === lastAttendedQuestionId);
          if (lastIndex !== -1) {
            setQuesIndex(lastIndex + 1); // Start from next question
          }
        }

        setLoading(false);
      })
      .catch(() => setLoading(false));
  };


  const loadQuestions = async () => {
    await axios
      .get(
        `${BASE_URL}/mockquestions/${user.user_id}/${titleId}?api_token=${token}`
      )
      .then(
        (res) => {
          setQuestions(res?.data?.result);

          setLoading(false);
        },
        (error) => {
          setLoading(false);
          Toast.show("Network error. Tryagain.", Toast.LONG);
        }
      );
  };

  const markForReview = (quesId: number) => {
    if (!isRunning) {
      Toast.show("Please resume the timer to start exam", Toast.LONG);
      return;
    }

    setMarkReview((prevItems) => {
      const isMarked = prevItems.includes(quesId);
      const updatedMarkReview = isMarked
        ? prevItems.filter((item) => item !== quesId) // Remove if already marked
        : [...prevItems, quesId]; // Add if not marked

      // Update the selectedOptions array
      setSelectedOptions((prevItems) => {
        const existingItem = prevItems.find((item) => item.question_id === quesId);

        if (existingItem) {
          // Update type to "mark-review-next" if the question is already in selectedOptions
          return prevItems.map((item) =>
            item.question_id === quesId
              ? { ...item, type: isMarked ? "save-next" : "mark-review-next" }
              : item
          );
        } else if (!isMarked) {
          // If question is not in selectedOptions, add a new entry with type "mark-review-next"
          return [...prevItems, { question_id: quesId, option_id: null, type: "mark-review-next" }];
        }

        return prevItems;
      });

      return updatedMarkReview;
    });
  };



  const confirmGuess = (quesId: number) => {
    if (!isRunning)
      Toast.show("Please resume the timer to start exam", Toast.LONG);
    else {
      const newItem = quesId;
      const itemIndex = guess.findIndex((item: any) => item === newItem);

      if (itemIndex !== -1) {
        // Item exists, remove it
        setGuess((prevItems) => {
          const updatedItems = [...prevItems];
          updatedItems.splice(itemIndex, 1);
          return updatedItems;
        });
      } else {
        // Item doesn't exist, add it
        setGuess((prevItems) => [...prevItems, newItem]);
      }
    }
  };

  const selectOption = (quesId: number, optId: number) => {
    if (!isRunning) {
      Toast.show("Please resume the timer to start exam", Toast.LONG);
      return;
    }

    setSelectedOptions((prevItems) => {
      const existingItem = prevItems.find((item) => item.question_id === quesId);
      const isMarkedForReview = markReview.includes(quesId);

      if (existingItem) {
        // Update existing entry with new option_id, keeping the correct type
        return prevItems.map((item) =>
          item.question_id === quesId
            ? { ...item, option_id: optId, type: isMarkedForReview ? "mark-review-next" : "save-next" }
            : item
        );
      } else {
        // Add a new entry with correct type
        return [...prevItems, { question_id: quesId, option_id: optId, type: "save-next" }];
      }
    });
  };


  const clearResponse = (quesId: number) => {
    if (!isRunning)
      Toast.show("Please resume the timer to start exam", Toast.LONG);
    else
      setSelectedOptions((prevItems) =>
        prevItems.filter((item) => item.question_id !== quesId)
      );
  };

  const loadPrevQuestion = () => {
    setQuesIndex(quesIndex - 1);
  };


  const loadNextQuestion = () => {
    if (!isRunning) {
      Toast.show("Please resume the timer to start exam", Toast.LONG);
      return;
    }

    setIsNextLoading(true); // Disable the button when clicked

    const currentQuestionId = questions?.[quesIndex]?.id;

    if (!currentQuestionId) {
      setIsNextLoading(false); // Re-enable button if question ID is missing
      return;
    }

    const isAttempted = selectedOptions.some(
      (option) => option.question_id === currentQuestionId
    );

    const isMarkedForReview = markReview.includes(currentQuestionId);

    if (isAttempted || isMarkedForReview) {
      // If the question is answered or marked for review, remove from skippedQues
      setSkippedQues((prevItems) =>
        prevItems.filter((item) => item !== currentQuestionId)
      );
    } else {
      // If not answered and not marked for review, add to skippedQues
      setSkippedQues((prevItems) =>
        prevItems.includes(currentQuestionId)
          ? prevItems
          : [...prevItems, currentQuestionId]
      );
    }

    setTimeout(() => {
      setQuesIndex((prevIndex) => prevIndex + 1);
      setIsNextLoading(false); // Re-enable button after question loads
    }, 300); // Simulated delay for loading (adjust as needed)
  };

  const handlePause = () => {
    // Alert.alert(
    //   "Pause Exam",
    //   "Are you sure you want to pause the exam?",
    //   [
    //     {
    //       text: "Cancel",
    //       style: "cancel",
    //     },
    //     {
    //       text: "Yes, Pause",
    //       onPress: () => setPauseModal(true), // Show pause modal
    //     },
    //   ],
    //   { cancelable: false }
    // );
    setPauseModal(true)
  };

  /** Resume Exam & Restart Timer */
  const handleResume = () => {
    setIsRunning(true); // Restart timer
    setPauseModal(false);
  };

  // const handleResume = () => {
  //   setIsRunning(true);
  //   setModal(false);
  // };

  const finishTest = () => {
    const lastQuestionId = questions?.[quesIndex]?.id;
    setTestEndedManually(true);
    // Ensure last question is added to skippedQues if no option was selected
    if (!selectedOptions.some((item) => item.question_id === lastQuestionId)) {
      setSkippedQues((prev) => [...prev, lastQuestionId]);
    }

    // Delay opening the modal to allow state updates
    setTimeout(() => {
      // setEndModal(true);/
      setVerifyQusModal(true)
    }, 100);
  };

  const endTest = () => {
    setVerifyQusModal(false);
    setEndModal(true);
  };

  const confirmPause = async () => {
    setSaving(true);

    await axios
      .post(
        `${BASE_URL}/savemock/${user.user_id}/${titleId}?api_token=${token}`,
        generatePayload()
      )
      .then(
        async (res) => {
          console.log("## confirm pause responser ##", res)
          await saveStatus("Paused", "", "", 1);
        },
        (error) => {
          setSaving(false);
          Toast.show("Network error. Tryagain.", Toast.LONG);
        }
      );
  };


  const generatePayload = () => {
    const answered = selectedOptions.map((item) => ({
      qid: item?.question_id,
      opt: item?.option_id,
      type: item?.type,
      guess: 0,
    }));

    console.log("## Answered", answered)

    const visited = skippedQues?.map((item) => ({
      qid: item,
      opt: 0,
      type: "visited",
      guess: 0,
    }));



    // **Ensure all unattempted questions are marked properly**
    const allQuestionIds = questions.map((q) => q.id); // Get all question IDs
    const attemptedQuestionIds = selectedOptions.map((item) => item.question_id);
    const visitedQuestionIds = skippedQues; // Already recorded as visited

    // **Filter only unattempted questions**
    const unattempted = allQuestionIds
      .filter((qid) => !attemptedQuestionIds.includes(qid) && !visitedQuestionIds.includes(qid))
      .map((qid) => ({
        qid,
        opt: 0,
        type: "visited",
        guess: 0,
      }));

    const payload = { answers: [...answered, ...visited, ...unattempted] };

    // Ensure latest markReview state is applied
    payload.answers = payload.answers.map((item) =>
      markReview.includes(item.qid) ? { ...item, type: "mark-review-next" } : item
    );

    payload.answers.forEach((item, index) => {
      if (guess.includes(item.qid)) {
        payload.answers[index].guess = 1;
      }
    });

    console.log("Generated Payload:", payload);
    return payload;
  };


  const confirmEnd = async () => {
    setSaving(true);

    await axios
      .post(
        `${BASE_URL}/savemock/${user.user_id}/${titleId}?api_token=${token}`,
        generatePayload()
      )
      .then(
        async (res) => {
          console.log("## save mock response --", res)
          setSaving(false);
          setModal(false);
          setEndModal(false);
          setVerifyQusModal(false)
          setIsRunning(false); // Stop the timer when exiting
          navigation.navigate("MockResult", {
            titleId: titleId,
            totalQues: totalQues,
            title: title,
          });
        },
        (error) => {
          setSaving(false);
          Toast.show("Network error. Tryagain.", Toast.LONG);
        }
      );
  };

  const saveStatus = async (statusText = "", start = "", end = "", type = 0) => {
    statusText = status === "Paused" ? "Paused" : statusText;
    console.log("## statusText ##", statusText)
    if (type) setSaving(true);
    await axios
      .post(
        `${BASE_URL}/savemockstatus/${user.user_id}/${titleId}?api_token=${token}`,
        { status: statusText, start_time: start, end_time: end }
      )
      .then(
        (res) => {
          if (type) {
            setSaving(false);
            setModal(false);
            setVerifyQusModal(false)
            setPauseModal(false);
            navigation.navigate("MockScreen");
          }
        },
        (error) => {
          setSaving(false);
          Toast.show("Network error. Tryagain.", Toast.LONG);
        }
      );
  };


  const handleSubmitQuestion = () => {
    if (!isRunning) {
      Toast.show("Please resume the timer to start exam", Toast.LONG);
      return;
    }

    const currentQuestionId = questions?.[quesIndex]?.id;
    if (!currentQuestionId) return;

    // Remove the question from "mark for review" if it exists there
    setMarkReview((prevItems) =>
      prevItems.filter((item) => item !== currentQuestionId)
    );

    // Update the question type
    const existingItem = selectedOptions.find(
      (item) => item.question_id === currentQuestionId
    );

    if (existingItem) {
      // If option is selected, update type to "save-next"
      setSelectedOptions((prevItems) =>
        prevItems.map((item) =>
          item.question_id === currentQuestionId
            ? { ...item, type: "save-next" }
            : item
        )
      );
    } else {
      // If no option is selected, mark as "visited"
      setSkippedQues((prevItems) => [...prevItems, currentQuestionId]);
    }

    // Open the verification modal
    setTimeout(() => {
      setVerifyQusModal(true);
    }, 300);
  };


  const hours = Math.floor(time / 3600);
  const minutes = Math.floor((time % 3600) / 60);
  const seconds = time % 60;
  const alphabets = ["A", "B", "C", "D"];

  // const renderers = {
  //   p: ({ TDefaultRenderer, ...defaultRendererProps }) => (
  //     <Text style={{ fontFamily: "Lato-Bold", lineHeight: 24 }}>
  //       <TDefaultRenderer {...defaultRendererProps} />
  //     </Text>
  //   ),
  //   span: ({ TDefaultRenderer, ...defaultRendererProps }) => (
  //     <Text style={{ fontFamily: "Lato-Bold", lineHeight: 24 }}>
  //       <TDefaultRenderer {...defaultRendererProps} />
  //     </Text>
  //   ),
  // };

  return (
    <>
      <Loading
        loading={loading || saving}
        text={
          loading
            ? "Loading questions. Please wait."
            : "Saving answers. Please wait."
        }
      />
      <View style={styles.container}>
        <View style={styles.header}>
          <Text
            style={[styles.bold16, { flex: 1, marginEnd: 10 }]}
            numberOfLines={1}
          >
            {title}
          </Text>
          <View style={styles.displayFlex}>
            <View style={[styles.displayFlex, styles.timer]}>
              <Ionicons name="time-outline" size={20} color="#000000" />
              <Text style={[styles.bold, styles.ms5]}>
                {time > 0
                  ? `${hours.toString().padStart(2, "0")}:${minutes
                    .toString()
                    .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`
                  : "00:00:00"}
              </Text>
            </View>
            {
              !isRunning ?
                <TouchableOpacity onPress={() => handleResume()}>
                  <Ionicons name="play-circle-outline" size={26} color="#000000" />
                </TouchableOpacity>
                :
                <TouchableOpacity onPress={() => handlePause()}>
                  <Ionicons name="pause-circle-outline" size={26} color="#000000" />
                </TouchableOpacity>
            }


          </View>
        </View>
        {questions?.length > 0 && (
          <>
            <View style={styles.innerContainer}>
              <View style={[styles.displayFlex, styles.justifyBetween]}>
                <Text style={styles.qTxt}>Question {quesIndex + 1}</Text>
                <TouchableOpacity
                  style={styles.displayFlex}
                  onPress={() => markForReview(questions?.[quesIndex]?.id)}
                >
                  <View style={{ transform: [{ scale: 0.7 }], marginTop: 3 }}>
                    <CheckBox
                      disabled
                      label=""
                      checked={markReview.includes(questions?.[quesIndex]?.id)}
                      onChange={() => markForReview(questions?.[quesIndex]?.id)}
                    />
                  </View>
                  <Text style={styles.qTxt}> Mark for review</Text>
                </TouchableOpacity>
              </View>
              <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
                <View>
                  <HTML
                   contentWidth={contentWidth}
                    source={{ html: questions?.[quesIndex]?.ques }}
                    tagsStyles={{
                      body: { fontFamily: "Lato-Black",fontSize: 16 },
                      p: { fontFamily: "Lato-Black",fontSize: 16 },
                      span: { fontFamily: "Lato-Black",fontSize: 16 },
                    }}
                    defaultTextProps={{
                      style: { fontFamily: "Lato-Black",fontSize: 16 },
                    }}
                  />
                  {questions?.[quesIndex]?.image && (
                    <Image
                      source={{
                        uri: `${WEB_URL}${questions?.[quesIndex]?.image}`,
                      }}
                      style={styles.quesImage}
                    />
                  )}
                </View>
              </ScrollView>
            </View>
            <View style={styles.answers}>
              <View style={[styles.aboveChoice, styles.mb10]}>
                <Text style={styles.colorGrey}>Select one option</Text>
                <TouchableOpacity
                  onPress={() => clearResponse(questions?.[quesIndex].id)}
                  style={styles.displayFlex}
                >
                  <Ionicons name="refresh" size={20} color="#888888" />
                  <Text style={[styles.colorGrey, styles.font12]}>
                    CLEAR RESPONSE {questions?.[quesIndex]?.type}
                  </Text>
                </TouchableOpacity>
              </View>
              {questions?.[quesIndex]?.options?.map((item, index) => (
                <TouchableOpacity
                  onPress={() =>
                    selectOption(questions?.[quesIndex]?.id, item.id)
                  }
                  style={
                    filter(selectedOptions, {
                      question_id: questions?.[quesIndex]?.id,
                      option_id: item?.id,
                    })?.length > 0
                      ? [styles.displayFlex, styles.choiceActive]
                      : [styles.displayFlex, styles.choice]
                  }
                  key={item?.id?.toString()}
                >
                  <Text style={styles.number}>{alphabets?.[index]}</Text>
                  <Text style={[styles.ms10, styles.opt]}>{item?.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.ms10}>
              <TouchableOpacity
                style={styles.displayFlex}
                onPress={() => confirmGuess(questions?.[quesIndex]?.id)}
              >
                <View style={{ transform: [{ scale: 0.7 }], marginTop: 3 }}>
                  <CheckBox
                    disabled
                    label=""
                    checked={guess.includes(questions?.[quesIndex]?.id)}
                    onChange={() => confirmGuess(questions?.[quesIndex]?.id)}
                  />
                </View>
                <Text style={styles.qTxt}> Guess answer</Text>
              </TouchableOpacity>
            </View>
            {quesIndex !== totalQues - 1 ? (
              <View style={styles.footer}>
                {quesIndex > 0 && (
                  <TouchableOpacity
                    onPress={loadPrevQuestion}
                    style={styles.btnActive}
                    disabled={isReviewing}
                  >
                    <Text style={styles.btnText}>Previous</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity
                  onPress={isReviewing ? handleSubmitQuestion : loadNextQuestion}
                  disabled={isNextLoading}
                  style={
                    filter(selectedOptions, {
                      question_id: questions?.[quesIndex]?.id,
                    })?.length > 0
                      ? styles.btnActive
                      : styles.btnDisabled
                  }
                >
                  <Text style={styles.btnText}>  {isReviewing ? "Submit" : "Next"}</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.footer}>
                <TouchableOpacity onPress={finishTest} style={styles.btnActive}>
                  <Text style={styles.btnText}>Finish test</Text>
                </TouchableOpacity>
              </View>
            )}
          </>
        )}
      </View>
      <QuestionsModal
        modalVisible={modal}
        setModalVisible={setModal}
        data={{ totalQues: totalQues }}
        questions={questions}
        selectedOptions={selectedOptions}
        setQuesIndex={setQuesIndex}
        skippedQues={skippedQues}
        isRunning={isRunning}
        handlePause={handlePause}
        handleResume={handleResume}
        endTest={endTest}
      />
      <AllQuestionsModal
        modalVisible={isVerify}
        setModalVisible={setVerifyQusModal}
        data={{ totalQues: totalQues }}
        questions={questions}
        selectedOptions={selectedOptions}
        setQuesIndex={setQuesIndex}
        skippedQues={skippedQues}
        markReview={markReview}
        setIsReviewing={setIsReviewing}
        title={title}
        endTest={endTest}
      />
      <EndModal
        modalVisible={endModal}
        setModalVisible={setEndModal}
        confirmEnd={confirmEnd}
      />
      <PauseModal
        modalVisible={pauseModal}
        setModalVisible={setPauseModal}
        confirmPause={confirmPause}
      />
    </>
  );
};

const mapStateToProps = (state: any) => ({
  isAuthenticated: state.authReducer.isAuthenticated,
  user: state.authReducer.user,
  token: state.authReducer.token,
});

export default connect(mapStateToProps)(StartMock);
