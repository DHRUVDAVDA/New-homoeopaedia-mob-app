import React, { useEffect, useState } from "react";
import { FlatList, ScrollView, Text, View } from "react-native";
import styles from "./ResultStyle";
import { connect } from "react-redux";
import { User } from "../_redux/reducers/types";
import axios from "axios";
import { BASE_URL } from "../consts";
import Toast from "react-native-simple-toast";
import Loading from "../layout/Loading";
import { TouchableOpacity } from "react-native-gesture-handler";
import SolutionItem from "./SolutionItem";
import {
	AntDesign,
	Entypo,
	FontAwesome,
	FontAwesome5,
} from "@expo/vector-icons";
import FilterModal from "./FilterModal";

type MyProps = {
	navigation: any;
	user: User;
	token: string;
	route: any;
	totalMarks: any;
	chartData: any;
};

const Solution = ({
	navigation,
	route,
	user,
	token,
	totalMarks,
	chartData,
}: MyProps) => {
	const { titleId, totalQues, title } = route.params;
	const [loading, setLoading] = useState(false);
	const [filter, setFilter] = useState(false);
	const [active, setActive] = useState("1-10");
	const [solution, setSolution] = useState([]);
	const [selectedId, setSelectedId] = useState("all");


	useEffect(() => {
		loadSolutions();
	}, []);

	const loadSolutions = async () => {
		setLoading(true);

		const split = active.split("-");

		await axios
			.get(
				`${BASE_URL}/solutions/${user.user_id}/${titleId}/${split[0]}/${split[1]}?api_token=${token}&type=${selectedId}`,
			)
			.then(
				(res) => {
					setSolution(res.data.result);
					const newSplit = splitNumberIntoGroups(
						res.data.result.length < 10
							? 10
							: res.data.result.length,
					);
					setActive(newSplit.length > 0 ? newSplit[0] : "1-10");
				},
				(error) => {
					Toast.show("Network error. Try again.", Toast.LONG);
				},
			);

		setLoading(false);
	};

	const loadPage = async (page: string) => {
		setLoading(true);
		setActive(page);

		const split = page.split("-");

		await axios
			.get(
				`${BASE_URL}/solutions/${user.user_id}/${titleId}/${split[0]}/${split[1]}?api_token=${token}&type=${selectedId}`,
			)
			.then(
				(res) => {
					setSolution(res.data.result);
				},
				(error) => {
					Toast.show("Network error. Try again.", Toast.LONG);
				},
			);

		setLoading(false);
	};

	function splitNumberIntoGroups(totalItems: number) {
		const groups = [];
		let start = 1;
		let end = 10;

		while (start <= totalItems) {
			if (end > totalItems) {
				end = totalItems;
			}

			groups.push(`${start}-${end}`);
			start = end + 1;
			end += 10;
		}

		return groups;
	}

	const confirmFilter = async () => {
		setFilter(false);
		setLoading(true);

		const split = active.split("-");

		await axios
			.get(
				`${BASE_URL}/solutions/${user.user_id}/${titleId}/${split[0]}/${split[1]}?api_token=${token}&type=${selectedId}`,
			)
			.then(
				(res) => {
					setSolution(res.data.result);
					const newSplit = splitNumberIntoGroups(
						res.data.result.length < 10
							? 10
							: res.data.result.length,
					);
					setActive(newSplit.length > 0 ? newSplit[0] : "1-10");
				},
				(error) => {
					Toast.show("Network error. Try again.", Toast.LONG);
				},
			);

		setLoading(false);
	};

	const getTotalQues = () => {
		if (selectedId === "correct") return totalMarks?.correct || 0;
		else if (selectedId === "wrong") return totalMarks?.wrong || 0;
		else if (selectedId === "attempted") return totalMarks?.attempted || 0;
		else if (selectedId === "unattempted")
			return totalQues - totalMarks?.attempted || 0;
		else if (selectedId === "guess") return totalMarks?.guess || 0;
		else if (selectedId === "review") return totalMarks?.review || 0;
		else return totalQues;
	};

	return (
		<>
			<View style={styles.containerNew}>
				<Loading
					loading={loading}
					text="Loading results. Please wait."
				/>
				<View>
					<ScrollView
						horizontal
						showsHorizontalScrollIndicator={false}
						contentContainerStyle={styles.horizontal}
					>
						<View style={styles.pagination}>
							{splitNumberIntoGroups(
								getTotalQues() < 10 ? 10 : getTotalQues(),
							).map((item, index) => (
								<TouchableOpacity
									onPress={() => loadPage(item)}
									key={index}
								>
									<Text
										style={
											active === item
												? styles.paginationSingleActive
												: styles.paginationSingle
										}
									>
										{item}
									</Text>
								</TouchableOpacity>
							))}
						</View>
					</ScrollView>
				</View>
				<View style={styles.container}>
					<FlatList
						data={solution}
						keyExtractor={(item) => item.id.toString()}
						contentContainerStyle={styles.innerContainerNew}
						renderItem={({ item, index }) => (
							<SolutionItem
								item={item}
								index={index}
								active={active}
								totalQues={totalQues}
								titleId={titleId}
								navigation={navigation}
							/>
						)}
						showsVerticalScrollIndicator={false}
					/>
				</View>
			</View>
			<View style={styles.filter}>
				<TouchableOpacity
					onPress={() => setFilter(true)}
					style={[styles.displayFlex, styles.filterTouch]}
				>
					<FontAwesome5 name="filter" size={12} color="#ffffff" />
					<Text style={styles.filterText}>Filters</Text>
				</TouchableOpacity>
			</View>
			<FilterModal
				modalVisible={filter}
				setModalVisible={setFilter}
				totalQues={totalQues}
				totalMarks={totalMarks}
				confirmFilter={confirmFilter}
				selectedId={selectedId}
				setSelectedId={setSelectedId}
			/>
		</>
	);
};

const mapStateToProps = (state: any) => ({
	isAuthenticated: state.authReducer.isAuthenticated,
	user: state.authReducer.user,
	token: state.authReducer.token,
});

export default connect(mapStateToProps)(Solution);
