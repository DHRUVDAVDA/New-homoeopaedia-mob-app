import React, { useState, useEffect } from "react";
import {
  Alert,
  BackHandler,
  Image,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import styles from "./MockStyle";
import { connect } from "react-redux";
import { User } from "../_redux/reducers/types";
import { Ionicons } from "@expo/vector-icons";
import QuestionsModal from "./QuestionsModal";
import axios from "axios";
import { BASE_URL, WEB_URL } from "../consts";
import Toast from "react-native-simple-toast";
import Loading from "../layout/Loading";
import HTML from "react-native-render-html";
import { filter } from "lodash";
import EndModal from "./EndModal";
import PauseModal from "./PauseModal";
import moment from "moment";
import CheckBox from "react-native-checkbox";
import AllQuestionsModal from "./AllQuestionsModal";
import { setStatusBarBackgroundColor } from "expo-status-bar";

type MyProps = {
  navigation: any;
  user: User;
  token: string;
  route: any;
};

const StartMock = ({ navigation, route, user, token }: MyProps) => {
  const { titleId, totalQues, title, status, duration, start, end } =
    route.params;
  const [time, setTime] = useState(duration * 60);
  const [modal, setModal] = useState(false);
  const [isVerify, setVerifyQusModal] = useState(false);
  const [endModal, setEndModal] = useState(false);
  const [pauseModal, setPauseModal] = useState(false);
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [quesIndex, setQuesIndex] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [markReview, setMarkReview] = useState([]);
  const [guess, setGuess] = useState([]);
  const [skippedQues, setSkippedQues] = useState([]);
  const [isRunning, setIsRunning] = useState(true);
  const [isNextLoading, setIsNextLoading] = useState(false);
  const [isReviewing, setIsReviewing] = useState(false);

  useEffect(() => {
    if (status === "Paused") {
      const startDatetime = moment(start);
      const endDatetime = moment(end);

      const durations = endDatetime.diff(startDatetime, "minutes");
      const remainingMinutes = duration - durations;

      setTime(remainingMinutes * 60);

      loadPausedQuestions();
    }
  }, [status]);

  useEffect(() => {
    if (time === 0) confirmEnd();
  }, [time]);

  useEffect(() => {
    saveStatus("");
    loadQuestions();
  }, []);

  useEffect(() => {
    let interval;

    if (isRunning) {
      interval = setInterval(() => {
        setTime((prevTime) => prevTime - 1);
      }, 1000);
    }

    // Return a cleanup function that clears the interval
    return () => clearInterval(interval);
  }, [isRunning]);

  useEffect(() => {
    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      () => {
        setModal(true);

        return true; // Prevent default behavior (exit app)
      }
    );

    return () => backHandler.remove();
  }, []);

  const loadPausedQuestions = async () => {
    setLoading(true);

    await axios
      .get(
        `${BASE_URL}/loadsavedmock/${user.user_id}/${titleId}?api_token=${token}`
      )
      .then(
        (res) => {
          const answered = res.data.result
            .filter((item: any) => item.type === "answered")
            .map((item: any) => ({
              question_id: parseInt(item.questions_id),
              option_id: parseInt(item.options_id),
              type: "save-next",
            }));

          setSelectedOptions(answered);

          const visited = res.data.result
            .filter((item: any) => item.type === "visited")
            .map((item: any) => item.questions_id);
          setSkippedQues(visited);

          setLoading(false);
        },
        (error) => {
          setLoading(false);
        }
      );
  };

  const loadQuestions = async () => {
    await axios
      .get(
        `${BASE_URL}/mockquestions/${user.user_id}/${titleId}?api_token=${token}`
      )
      .then(
        (res) => {
          setQuestions(res?.data?.result);

          setLoading(false);
        },
        (error) => {
          setLoading(false);
          Toast.show("Network error. Tryagain.", Toast.LONG);
        }
      );
  };

  const markForReview = (quesId: number) => {
    if (!isRunning) {
      Toast.show("Please resume the timer to start exam", Toast.LONG);
      return;
    }

    setMarkReview((prevItems) => {
      const isMarked = prevItems.includes(quesId);
      const updatedMarkReview = isMarked
        ? prevItems.filter((item) => item !== quesId) // Remove if already marked
        : [...prevItems, quesId]; // Add if not marked

      // Update the selectedOptions array
      setSelectedOptions((prevItems) => {
        const existingItem = prevItems.find((item) => item.question_id === quesId);

        if (existingItem) {
          // Update type to "mark-review-next" if the question is already in selectedOptions
          return prevItems.map((item) =>
            item.question_id === quesId
              ? { ...item, type: isMarked ? "save-next" : "mark-review-next" }
              : item
          );
        } else if (!isMarked) {
          // If question is not in selectedOptions, add a new entry with type "mark-review-next"
          return [...prevItems, { question_id: quesId, option_id: null, type: "mark-review-next" }];
        }

        return prevItems;
      });

      return updatedMarkReview;
    });
  };



  const confirmGuess = (quesId: number) => {
    if (!isRunning)
      Toast.show("Please resume the timer to start exam", Toast.LONG);
    else {
      const newItem = quesId;
      const itemIndex = guess.findIndex((item: any) => item === newItem);

      if (itemIndex !== -1) {
        // Item exists, remove it
        setGuess((prevItems) => {
          const updatedItems = [...prevItems];
          updatedItems.splice(itemIndex, 1);
          return updatedItems;
        });
      } else {
        // Item doesn't exist, add it
        setGuess((prevItems) => [...prevItems, newItem]);
      }
    }
  };

  const selectOption = (quesId: number, optId: number) => {
    if (!isRunning) {
      Toast.show("Please resume the timer to start exam", Toast.LONG);
      return;
    }

    setSelectedOptions((prevItems) => {
      const existingItem = prevItems.find((item) => item.question_id === quesId);
      const isMarkedForReview = markReview.includes(quesId);

      if (existingItem) {
        // Update existing entry with new option_id, keeping the correct type
        return prevItems.map((item) =>
          item.question_id === quesId
            ? { ...item, option_id: optId, type: isMarkedForReview ? "mark-review-next" : "save-next" }
            : item
        );
      } else {
        // Add a new entry with correct type
        return [...prevItems, { question_id: quesId, option_id: optId, type: "save-next" }];
      }
    });
  };


  const clearResponse = (quesId: number) => {
    if (!isRunning)
      Toast.show("Please resume the timer to start exam", Toast.LONG);
    else
      setSelectedOptions((prevItems) =>
        prevItems.filter((item) => item.question_id !== quesId)
      );
  };

  const loadPrevQuestion = () => {
    setQuesIndex(quesIndex - 1);
  };


  const loadNextQuestion = () => {
    if (!isRunning) {
      Toast.show("Please resume the timer to start exam", Toast.LONG);
      return;
    }

    setIsNextLoading(true); // Disable the button when clicked

    const currentQuestionId = questions?.[quesIndex]?.id;

    if (!currentQuestionId) {
      setIsNextLoading(false); // Re-enable button if question ID is missing
      return;
    }

    const isAttempted = selectedOptions.some(
      (option) => option.question_id === currentQuestionId
    );

    const isMarkedForReview = markReview.includes(currentQuestionId);

    if (isAttempted || isMarkedForReview) {
      // If the question is answered or marked for review, remove from skippedQues
      setSkippedQues((prevItems) =>
        prevItems.filter((item) => item !== currentQuestionId)
      );
    } else {
      // If not answered and not marked for review, add to skippedQues
      setSkippedQues((prevItems) =>
        prevItems.includes(currentQuestionId)
          ? prevItems
          : [...prevItems, currentQuestionId]
      );
    }

    setTimeout(() => {
      setQuesIndex((prevIndex) => prevIndex + 1);
      setIsNextLoading(false); // Re-enable button after question loads
    }, 300); // Simulated delay for loading (adjust as needed)
  };

  const handlePause = () => {
    Alert.alert(
      "Pause Exam",
      "Are you sure you want to pause the exam?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Yes, Pause",
          onPress: () => setPauseModal(true), // Show pause modal
        },
      ],
      { cancelable: false }
    );
  };


  const handleResume = () => {
    setIsRunning(true);
    setModal(false);
  };

  const finishTest = () => {
    const lastQuestionId = questions?.[quesIndex]?.id;

    // Ensure last question is added to skippedQues if no option was selected
    if (!selectedOptions.some((item) => item.question_id === lastQuestionId)) {
      setSkippedQues((prev) => [...prev, lastQuestionId]);
    }

    // Delay opening the modal to allow state updates
    setTimeout(() => {
      // setEndModal(true);/
      setVerifyQusModal(true)
    }, 100);
  };

  const endTest = () => {
    setEndModal(true);
  };

  const confirmPause = async () => {
    setSaving(true);

    await axios
      .post(
        `${BASE_URL}/savemock/${user.user_id}/${titleId}?api_token=${token}`,
        generatePayload()
      )
      .then(
        async (res) => {
          console.log("## confirm pause responser ##", res)
          await saveStatus("Paused", 1);
        },
        (error) => {
          setSaving(false);
          Toast.show("Network error. Tryagain.", Toast.LONG);
        }
      );
  };


  const generatePayload = () => {
    const answered = selectedOptions.map((item) => ({
      qid: item?.question_id,
      opt: item?.option_id,
      type: item?.type,
      guess: 0,
    }));

    console.log("## Answered", answered)

    const visited = skippedQues?.map((item) => ({
      qid: item,
      opt: 0,
      type: "visited",
      guess: 0,
    }));



    // **Ensure all unattempted questions are marked properly**
    const allQuestionIds = questions.map((q) => q.id); // Get all question IDs
    const attemptedQuestionIds = selectedOptions.map((item) => item.question_id);
    const visitedQuestionIds = skippedQues; // Already recorded as visited

    // **Filter only unattempted questions**
    const unattempted = allQuestionIds
      .filter((qid) => !attemptedQuestionIds.includes(qid) && !visitedQuestionIds.includes(qid))
      .map((qid) => ({
        qid,
        opt: 0,
        type: "visited",
        guess: 0,
      }));

    const payload = { answers: [...answered, ...visited, ...unattempted] };

    // Ensure latest markReview state is applied
    payload.answers = payload.answers.map((item) =>
      markReview.includes(item.qid) ? { ...item, type: "mark-review-next" } : item
    );

    payload.answers.forEach((item, index) => {
      if (guess.includes(item.qid)) {
        payload.answers[index].guess = 1;
      }
    });

    console.log("Generated Payload:", payload);
    return payload;
  };


  const confirmEnd = async () => {
    setSaving(true);

    await axios
      .post(
        `${BASE_URL}/savemock/${user.user_id}/${titleId}?api_token=${token}`,
        generatePayload()
      )
      .then(
        async (res) => {
          console.log("## save mock response --", res)
          setSaving(false);
          setModal(false);
          setEndModal(false);
          navigation.navigate("MockResult", {
            titleId: titleId,
            totalQues: totalQues,
            title: title,
          });
        },
        (error) => {
          setSaving(false);
          Toast.show("Network error. Tryagain.", Toast.LONG);
        }
      );
  };

  const saveStatus = async (statusText = "", type = 0) => {
    statusText = status === "" ? "Paused" : statusText;
    console.log("## statusText ##", statusText)
    if (type) setSaving(true);

    await axios
      .post(
        `${BASE_URL}/savemockstatus/${user.user_id}/${titleId}?api_token=${token}`,
        { status: statusText }
      )
      .then(
        (res) => {
          if (type) {
            setSaving(false);
            setModal(false);
            setPauseModal(false);
            navigation.navigate("MockScreen");
          }
        },
        (error) => {
          setSaving(false);
          Toast.show("Network error. Tryagain.", Toast.LONG);
        }
      );
  };


  const handleSubmitQuestion = () => {
    if (!isRunning) {
      Toast.show("Please resume the timer to start exam", Toast.LONG);
      return;
    }

    const currentQuestionId = questions?.[quesIndex]?.id;
    if (!currentQuestionId) return;

    // Remove the question from "mark for review" if it exists there
    setMarkReview((prevItems) =>
      prevItems.filter((item) => item !== currentQuestionId)
    );

    // Update the question type
    const existingItem = selectedOptions.find(
      (item) => item.question_id === currentQuestionId
    );

    if (existingItem) {
      // If option is selected, update type to "save-next"
      setSelectedOptions((prevItems) =>
        prevItems.map((item) =>
          item.question_id === currentQuestionId
            ? { ...item, type: "save-next" }
            : item
        )
      );
    } else {
      // If no option is selected, mark as "visited"
      setSkippedQues((prevItems) => [...prevItems, currentQuestionId]);
    }

    // Open the verification modal
    setTimeout(() => {
      setVerifyQusModal(true);
    }, 300);
  };


  const hours = Math.floor(time / 3600);
  const minutes = Math.floor((time % 3600) / 60);
  const seconds = time % 60;
  const alphabets = ["A", "B", "C", "D"];

  return (
    <>
      <Loading
        loading={loading || saving}
        text={
          loading
            ? "Loading questions. Please wait."
            : "Saving answers. Please wait."
        }
      />
      <View style={styles.container}>
        <View style={styles.header}>
          <Text
            style={[styles.bold16, { flex: 1, marginEnd: 10 }]}
            numberOfLines={1}
          >
            {title}
          </Text>
          <View style={styles.displayFlex}>
            <View style={[styles.displayFlex, styles.timer]}>
              <Ionicons name="time-outline" size={20} color="#000000" />
              <Text style={[styles.bold, styles.ms5]}>
                {time > 0
                  ? `${hours.toString().padStart(2, "0")}:${minutes
                    .toString()
                    .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`
                  : "00:00:00"}
              </Text>
            </View>
            <TouchableOpacity onPress={() => handlePause()}>
              <Ionicons name="pause-circle-outline" size={26} color="#000000" />
            </TouchableOpacity>
          </View>
        </View>
        {questions?.length > 0 && (
          <>
            <View style={styles.innerContainer}>
              <View style={[styles.displayFlex, styles.justifyBetween]}>
                <Text>Question {quesIndex + 1}</Text>
                <TouchableOpacity
                  style={styles.displayFlex}
                  onPress={() => markForReview(questions?.[quesIndex]?.id)}
                >
                  <View style={{ transform: [{ scale: 0.7 }], marginTop: 3 }}>
                    <CheckBox
                      disabled
                      label=""
                      checked={markReview.includes(questions?.[quesIndex]?.id)}
                      onChange={() => markForReview(questions?.[quesIndex]?.id)}
                    />
                  </View>
                  <Text> Mark for review</Text>
                </TouchableOpacity>
              </View>
              <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
                <View>
                  <HTML
                    source={{
                      html: questions?.[quesIndex]?.ques,
                    }}
                    tagsStyles={{
                      body: {
                        fontSize: 16,
                        color: '#000',
                        fontWeight: 'bold'
                      },
                    }}
                  />
                  {questions?.[quesIndex]?.image && (
                    <Image
                      source={{
                        uri: `${WEB_URL}${questions?.[quesIndex]?.image}`,
                      }}
                      style={styles.quesImage}
                    />
                  )}
                </View>
              </ScrollView>
            </View>
            <View style={styles.answers}>
              <View style={[styles.aboveChoice, styles.mb10]}>
                <Text style={styles.colorGrey}>Select one option</Text>
                <TouchableOpacity
                  onPress={() => clearResponse(questions?.[quesIndex].id)}
                  style={styles.displayFlex}
                >
                  <Ionicons name="refresh" size={20} color="#888888" />
                  <Text style={[styles.colorGrey, styles.font12]}>
                    CLEAR RESPONSE {questions?.[quesIndex]?.type}
                  </Text>
                </TouchableOpacity>
              </View>
              {questions?.[quesIndex]?.options?.map((item, index) => (
                <TouchableOpacity
                  onPress={() =>
                    selectOption(questions?.[quesIndex]?.id, item.id)
                  }
                  style={
                    filter(selectedOptions, {
                      question_id: questions?.[quesIndex]?.id,
                      option_id: item?.id,
                    })?.length > 0
                      ? [styles.displayFlex, styles.choiceActive]
                      : [styles.displayFlex, styles.choice]
                  }
                  key={item?.id?.toString()}
                >
                  <Text style={styles.number}>{alphabets?.[index]}</Text>
                  <Text style={styles.ms10}>{item?.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.ms10}>
              <TouchableOpacity
                style={styles.displayFlex}
                onPress={() => confirmGuess(questions?.[quesIndex]?.id)}
              >
                <View style={{ transform: [{ scale: 0.7 }], marginTop: 3 }}>
                  <CheckBox
                    disabled
                    label=""
                    checked={guess.includes(questions?.[quesIndex]?.id)}
                    onChange={() => confirmGuess(questions?.[quesIndex]?.id)}
                  />
                </View>
                <Text> Guess answer</Text>
              </TouchableOpacity>
            </View>
            {quesIndex !== totalQues - 1 ? (
              <View style={styles.footer}>
                {quesIndex > 0 && (
                  <TouchableOpacity
                    onPress={loadPrevQuestion}
                    style={styles.btnActive}
                    disabled={isReviewing}
                  >
                    <Text style={styles.btnText}>Previous</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity
                  onPress={isReviewing ? handleSubmitQuestion : loadNextQuestion}
                  disabled={isNextLoading}
                  style={
                    filter(selectedOptions, {
                      question_id: questions?.[quesIndex]?.id,
                    })?.length > 0
                      ? styles.btnActive
                      : styles.btnDisabled
                  }
                >
                  <Text style={styles.btnText}>  {isReviewing ? "Submit" : "Next"}</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.footer}>
                <TouchableOpacity onPress={finishTest} style={styles.btnActive}>
                  <Text style={styles.btnText}>Finish test</Text>
                </TouchableOpacity>
              </View>
            )}
          </>
        )}
      </View>
      <QuestionsModal
        modalVisible={modal}
        setModalVisible={setModal}
        data={{ totalQues: totalQues }}
        questions={questions}
        selectedOptions={selectedOptions}
        setQuesIndex={setQuesIndex}
        skippedQues={skippedQues}
        isRunning={isRunning}
        handlePause={handlePause}
        handleResume={handleResume}
        endTest={endTest}
      />
      <AllQuestionsModal
        modalVisible={isVerify}
        setModalVisible={setVerifyQusModal}
        data={{ totalQues: totalQues }}
        questions={questions}
        selectedOptions={selectedOptions}
        setQuesIndex={setQuesIndex}
        skippedQues={skippedQues}
        markReview={markReview}
        setIsReviewing={setIsReviewing}
        title={title}
        endTest={endTest}
      />
      <EndModal
        modalVisible={endModal}
        setModalVisible={setEndModal}
        confirmEnd={confirmEnd}
      />
      <PauseModal
        modalVisible={pauseModal}
        setModalVisible={setPauseModal}
        confirmPause={confirmPause}
      />
    </>
  );
};

const mapStateToProps = (state: any) => ({
  isAuthenticated: state.authReducer.isAuthenticated,
  user: state.authReducer.user,
  token: state.authReducer.token,
});

export default connect(mapStateToProps)(StartMock);
