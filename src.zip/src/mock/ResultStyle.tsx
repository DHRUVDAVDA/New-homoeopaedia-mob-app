import { StyleSheet } from "react-native";

const ResultStyle = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#ffffff",
	},
	containerNew: {
		flex: 1,
		backgroundColor: "#ffffff",
	},
	innerContainer: {
		marginHorizontal: 20,
		marginVertical: 10,
		flexGrow: 1,
	},
	innerContainerNew: {
		flexGrow: 1,
	},
	innerContainerNews: {
		marginVertical: 15,
		flexGrow: 1,
	},
	displayFlex: {
		flexDirection: "row",
		alignItems: "center",
	},
	bold: {
		fontFamily:'Lato-Black',
		fontSize: 16,
	},
	subheading: {
		color: "#888888",
		fontFamily:'Lato-Bold'
	},
	ms10: {
		marginStart: 10,
	},
	mt20: {
		marginTop: 20,
	},
	mt10: {
		marginTop: 10,
	},
	section: {
		marginTop: 20,
	},
	heading: {
		fontSize: 18,
		fontFamily:'Lato-Black'
	},
	footer: {
		borderTopColor: "#e9e9e9",
		borderTopWidth: 1,
		paddingVertical: 10,
		paddingHorizontal: 20,
		backgroundColor: "#ffffff",
	},
	btnStart: {
		backgroundColor: "#22bdc1",
		padding: 10,
		borderRadius: 5,
		marginTop: 10,
	},
	btnDisabled: {
		backgroundColor: "#888888",
		padding: 10,
		borderRadius: 5,
		marginTop: 10,
	},
	btnText: {
		textAlign: "center",
		color: "#ffffff",
	},
	mb20: {
		marginBottom: 20,
	},
	line: {
		borderBottomWidth: 1,
		borderBottomColor: "#e9e9e9",
		marginVertical: 20,
		marginBottom: 15,
	},
	box: {
		borderWidth: 1,
		borderColor: "#e9e9e9",
		justifyContent: "center",
		alignItems: "center",
		padding: 10,
		marginTop: 15,
		borderRadius: 5,
	},
	grey: {
		color: "#888888",
		fontWeight: "normal",
	},
	flexDirection: {
		flexDirection: "row",
	},
	flex: {
		flex: 1,
	},
	me10: {
		marginEnd: 10,
	},
	fs12: {
		fontSize: 12,
		textAlign: "center",
	},
	chart: {
		marginTop: 20,
		alignItems: "center",
	},
	horizontal: {
		marginVertical: 15,
	},
	pagination: {
		flexDirection: "row",
	},
	paginationSingleActive: {
		paddingHorizontal: 10,
		paddingVertical: 5,
		borderWidth: 1,
		borderColor: "#e9e9e9",
		borderRadius: 20,
		backgroundColor: "#ffffff",
		marginRight: 15,
	},
	paginationSingle: {
		paddingHorizontal: 10,
		paddingVertical: 5,
		borderWidth: 1,
		borderColor: "#e9e9e9",
		borderRadius: 20,
		backgroundColor: "#e9e9e9",
		marginRight: 15,
	},
	answer: {
		flexDirection: "row",
		alignItems: "flex-start",
		marginBottom: 10
	},
	numbering: {
		paddingHorizontal: 10,
		paddingVertical: 5,
		borderWidth: 1,
		borderColor: "#888888",
		borderRadius: 5,
		fontWeight: "bold",
		marginRight: 20,
		color: "#888888",
	},
	numberingActive: {
		paddingHorizontal: 10,
		paddingVertical: 5,
		borderWidth: 1,
		borderColor: "green",
		borderRadius: 5,
		fontWeight: "bold",
		marginRight: 20,
		color: "green",
	},
	numberingWrong: {
		paddingHorizontal: 10,
		paddingVertical: 5,
		borderWidth: 1,
		borderColor: "red",
		borderRadius: 5,
		fontWeight: "bold",
		marginRight: 20,
		color: "red",
	},
	question: {
		fontWeight: "bold",
	},
	dot: {
		fontWeight: "bold",
		color: "#888888",
		marginHorizontal: 10,
	},
	colorGrey: {
		color: "#888888",
	},
	colorGreen: {
		color: "green",
	},
	colorRed: {
		color: "red",
	},
	mb10: {
		marginBottom: 10,
	},
	filter: {
		position: "absolute",
		bottom: 10,
		alignSelf: "center",
	},
	filterTouch: {
		backgroundColor: "#000000",
		paddingHorizontal: 20,
		paddingVertical: 5,
		borderRadius: 20,
	},
	filterText: {
		color: "#ffffff",
		fontSize: 16,
		fontFamily:'Lato-Black',
		marginLeft: 5,
	},
	options: {
		borderWidth: 1,
		borderColor: "#cccccc",
		padding: 10,
		borderRadius: 5,
		marginBottom: 10,
		fontFamily:'Lato-Black',
	},
	active: {
		borderColor: "green",
	},
	wrong: {
		borderColor: "red",
	},
	correctText: {
		color: "green",
		fontFamily:'Lato-Black',
		textAlign: "right",
		marginBottom: 10,
	},
	wrongText: {
		color: "red",
		fontFamily:'Lato-Black',
		textAlign: "right",
		marginBottom: 10,
	},
	quesImage: {
		width: "100%",
		height: 100,
		// flex: 1,
		resizeMode: "contain",
	},
	fntStyle:{
		fontFamily:'Lato-Bold',
		color:'red',
	},
	centeredView: {
		flex: 1,
		justifyContent: "center",
		// alignItems: "center",
		backgroundColor: "rgba(0, 0, 0, 0.5)",
	},
	modalView: {
		margin: 20,
		backgroundColor: "white",
		borderRadius: 20,
		padding: 20,
		alignItems: "center",
		shadowColor: "#000",
		shadowOffset: {
			width: 0,
			height: 2,
		},
		shadowOpacity: 0.25,
		shadowRadius: 4,
		elevation: 5,
	},
	modalText: {
		marginBottom: 15,
		textAlign: "center",
		fontSize: 16,
		fontWeight: "bold",
	},
	label: {
		textAlign: "left",
		alignSelf: "flex-start",
	},
	issue: {
		borderColor: "#000000",
		borderWidth: 1,
		padding: 10,
		width: "100%",
		marginTop: 10,
	},
	modalButtons: {
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "space-between",
	},
	button: {
		borderRadius: 20,
		padding: 10,
		elevation: 2,
		marginTop: 20,
		flex: 1,
	},
	buttonOpen: {
		backgroundColor: "#F194FF",
	},
	buttonClose: {
		backgroundColor: "#2196F3",
	},
	mr10: {
		marginRight: 10,
		backgroundColor: "green",
	},
	textStyle: {
		color: "white",
		fontWeight: "bold",
		textAlign: "center",
	},
	ml10: {
		marginLeft: 10,
	},
	thin:{
		fontFamily:'Lato-Bold'
	},
	qtxt:{
		fontFamily:'Lato-Black'
	},
});

export default ResultStyle;
