import React, { useEffect, useState } from "react";
import { BackHandler, Dimensions, ScrollView, Text, View } from "react-native";
import styles from "./ResultStyle";
import { connect } from "react-redux";
import { User } from "../_redux/reducers/types";
import { Ionicons } from "@expo/vector-icons";
import { PieChart } from "react-native-chart-kit";
import moment from "moment";

type MyProps = {
	navigation: any;
	user: User;
	token: string;
	route: any;
	totalMarks: any;
	chartData: any;
};

// const chartConfig = {
// 	backgroundGradientFrom: "#1E2923",
// 	backgroundGradientFromOpacity: 0,
// 	backgroundGradientTo: "#08130D",
// 	backgroundGradientToOpacity: 0.5,
// 	color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
// 	strokeWidth: 2, // optional, default 3
// 	barPercentage: 0.5,
// 	useShadowColorFromDataset: false, // optional
// };

const chartConfig = {
	backgroundGradientFrom: "#1E2923",
	backgroundGradientFromOpacity: 0,
	backgroundGradientTo: "#08130D",
	backgroundGradientToOpacity: 0.5,
	color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
	strokeWidth: 2, // optional, default 3
	barPercentage: 0.5,
	useShadowColorFromDataset: false, // optional
	labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`, // Label color
	propsForLabels: {
	  fontFamily: "Lato-Bold", // Custom font
	  fontSize: 14, // Adjust size if needed
	  fontWeight: "bold",
	},
  };
  

const ResultOverview = ({
	navigation,
	route,
	user,
	token,
	totalMarks,
	chartData,
}: MyProps) => {
	const { titleId, totalQues, title } = route.params;


	return (
		<View style={styles.container}>
			<ScrollView contentContainerStyle={styles.innerContainerNews}>
				<View style={styles.displayFlex}>
					<Ionicons name="trophy" size={30} color="#000000" />
					<View style={styles.ms10}>
						<Text style={styles.bold}>{title}</Text>
						<Text style={styles.subheading}>
							{totalMarks.date}
						</Text>
					</View>
				</View>
				<View style={styles.line} />
				<Text style={styles.bold}>Overview</Text>
				<View style={styles.box}>
					<Text style={styles.thin}>MARKS</Text>
					<Text style={styles.bold}>
						{parseInt(totalMarks?.marks) || 0}
						<Text style={styles.grey}>/{totalMarks?.total_marks}</Text>
					</Text>
				</View>
				<View style={styles.line} />
				<Text style={styles.bold}>Test summary</Text>
				<View style={styles.flexDirection}>
					<View style={[styles.box, styles.flex]}>
						<Text style={styles.bold}>
							{totalMarks?.attempted || 0}
						</Text>
						<Text style={[styles.subheading, styles.fs12]}>
							Questions attempted
						</Text>
					</View>
					<View style={[styles.box, styles.flex, styles.ms10]}>
						<Text style={styles.bold}>
							{totalMarks?.correct || 0}
						</Text>
						<Text style={[styles.subheading, styles.fs12]}>
							Correct answers
						</Text>
					</View>
				</View>
				<View style={styles.flexDirection}>
					<View style={[styles.box, styles.flex]}>
						<Text style={styles.bold}>
							{/* {totalQues - totalMarks?.attempted} */}
							{totalMarks?.unattempted}
						</Text>
						<Text style={[styles.subheading, styles.fs12]}>
							Unattempted questions
						</Text>
					</View>
					<View style={[styles.box, styles.flex, styles.ms10]}>
						<Text style={styles.bold}>
							{totalMarks?.wrong || 0}
						</Text>
						<Text style={[styles.subheading, styles.fs12]}>
							Wrong answers
						</Text>
					</View>
				</View>
				<View style={styles.chart}>
					<PieChart
						data={chartData}
						width={Dimensions.get("window").width}
						height={150}
						chartConfig={chartConfig}
						accessor={"population"}
						backgroundColor={"transparent"}
						paddingLeft="-35"
						center={[50, -10]}
						absolute
					/>
				</View>
			</ScrollView>
		</View>
	);
};

const mapStateToProps = (state: any) => ({
	isAuthenticated: state.authReducer.isAuthenticated,
	user: state.authReducer.user,
	token: state.authReducer.token,
});

export default connect(mapStateToProps)(ResultOverview);
